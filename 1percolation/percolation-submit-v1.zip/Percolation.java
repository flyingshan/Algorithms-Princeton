import edu.princeton.cs.algs4.StdRandom;
//import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import edu.princeton.cs.algs4.StdOut;
public class Percolation {
	private int N; //N*N gird
	private WeightedQuickUnionUF cgrid;// init and final site
	private int[] opengrid;
	public Percolation(int n)                // create n-by-n grid, with all sites blocked
	{
		N = n;
		cgrid = new WeightedQuickUnionUF(n*n+2); // init and final site
		opengrid = new int[n*n+2];
		for(int i = 1;i<=N;i++)
		{cgrid.union(0,i);}
		for(int i = n*n; i>n*n-n; i--)
		{cgrid.union(n*n+1,i);}
	}
	public void open(int row, int col)    // open site (row, col) if it is not open already
	{
		if(!isOpen(row, col))	
		{
			opengrid[(row-1)*N+col]= 1;
			if(row == 1)
			{
				if(opengrid[(row-1)*N+col+1]==1) cgrid.union((row-1)*N+col,(row-1)*N+col+1);
				if(opengrid[(row-1)*N+col-1]==1) cgrid.union((row-1)*N+col,(row-1)*N+col-1);
				if(opengrid[(row-1)*N+col+N]==1) cgrid.union((row-1)*N+col,(row-1)*N+col+N);
			}
			else if(row == N)
			{
				if(opengrid[(row-1)*N+col+1]==1) cgrid.union((row-1)*N+col,(row-1)*N+col+1);
				if(opengrid[(row-1)*N+col-1]==1) cgrid.union((row-1)*N+col,(row-1)*N+col-1);
				if(opengrid[(row-1)*N+col-N]==1) cgrid.union((row-1)*N+col,(row-1)*N+col-N);
			}
			else
			{
				if(opengrid[(row-1)*N+col+1]==1) cgrid.union((row-1)*N+col,(row-1)*N+col+1);
				if(opengrid[(row-1)*N+col-1]==1) cgrid.union((row-1)*N+col,(row-1)*N+col-1);
				if(opengrid[(row-1)*N+col+N]==1) cgrid.union((row-1)*N+col,(row-1)*N+col+N);
				if(opengrid[(row-1)*N+col-N]==1) cgrid.union((row-1)*N+col,(row-1)*N+col-N);
			}
		}
	}
	public boolean isOpen(int row, int col)  // is site (row, col) open?
	{return opengrid[(row-1)*N+col]==1;}
	public boolean isFull(int row, int col)  // is site (row, col) full?
	{return cgrid.connected(0,(row-1)*N+col);}
	public int numberOfOpenSites()       // number of open sites
	{	
		int num_open = 0;
		for(int i = 1;i<=N*N;i++)
			if(opengrid[i]==1) {num_open++;}
		return num_open;
	}
	public boolean percolates()              // does the system percolate?
	{return cgrid.connected(0,N*N+1);}
	public static void main(String[] args)   // test client (optional)
	{
		int NN = Integer.parseInt(args[0]);
		Percolation p = new Percolation(NN);
		while(!p.percolates())//while not percolated randomly choose one place to open
		{	
			int row_t = StdRandom.uniform(NN)+1;
			int col_t = StdRandom.uniform(NN)+1;
			p.open(row_t,col_t);
		}
		double prob = ((double)p.numberOfOpenSites())/(NN*NN);
		StdOut.print(prob);
	}
}