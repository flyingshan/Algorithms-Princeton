import edu.princeton.cs.algs4.StdRandom;
// import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import edu.princeton.cs.algs4.StdOut;
public class Percolation {
   private final int nDim; // nDim*nDim gird
   private int openSiteNum;
   private WeightedQuickUnionUF cgrid; // init and final site
   private boolean[] opengrid;
   public Percolation(int n)                // create n-by-n grid, with all sites blocked
   {
	  if (n <= 0) throw new java.lang.IllegalArgumentException();
	  openSiteNum = 0;
      nDim = n;
      cgrid = new WeightedQuickUnionUF(n*n+2); // init and final site
      opengrid = new boolean[n*n+2];
      for (int i = 1;i <= nDim;i++)
      { cgrid.union(0, i); }
      for (int i = n*n; i > n*n-n; i--)
      { cgrid.union(n*n+1, i); }
   }
   private int indicehelper(int row, int col)
   {
	   return (row-1)*nDim+col;
   }
   public void open(int row, int col)    // open site (row, col) if it is not open already
   {
	  if (row <= 0|| col <= 0|| row > nDim|| col > nDim)
		  throw new java.lang.IllegalArgumentException();
      if (!isOpen(row, col))   
      {
		 openSiteNum++;
         opengrid[(row-1)*nDim+col] = true;
         if (row == 1)
         {
            if (opengrid[indicehelper(row,col)+1]) cgrid.union(indicehelper(row,col), indicehelper(row,col)+1);
            if (opengrid[indicehelper(row,col)-1]) cgrid.union(indicehelper(row,col), indicehelper(row,col)-1);
            if (opengrid[indicehelper(row,col)+nDim]) cgrid.union(indicehelper(row,col), indicehelper(row,col)+nDim);
         }
         else if (row == nDim)
         {
            if (opengrid[indicehelper(row,col)+1]) cgrid.union(indicehelper(row,col), indicehelper(row,col)+1);
            if (opengrid[indicehelper(row,col)-1]) cgrid.union(indicehelper(row,col), indicehelper(row,col)-1);
            if (opengrid[indicehelper(row,col)-nDim]) cgrid.union(indicehelper(row,col), indicehelper(row,col)-nDim);
         }
         else
         {
            if (opengrid[indicehelper(row,col)+1]) cgrid.union(indicehelper(row,col), indicehelper(row,col)+1);
            if (opengrid[indicehelper(row,col)-1]) cgrid.union(indicehelper(row,col), indicehelper(row,col)-1);
            if (opengrid[indicehelper(row,col)+nDim]) cgrid.union(indicehelper(row,col), indicehelper(row,col)+nDim);
            if (opengrid[indicehelper(row,col)-nDim]) cgrid.union(indicehelper(row,col),indicehelper(row,col)-nDim);
         }
      }
   }
   public boolean isOpen(int row, int col)  // is site (row, col) open?
   { 
   	  if (row <= 0|| col <= 0|| row > nDim|| col > nDim)
		  throw new java.lang.IllegalArgumentException();
      return opengrid[indicehelper(row,col)]==true; 
   }
   public boolean isFull(int row, int col)  // is site (row, col) full?
   { 
   	  if (row <= 0|| col <= 0|| row > nDim|| col > nDim)
		  throw new java.lang.IllegalArgumentException();
      return isOpen(row, col)&&cgrid.connected(0,indicehelper(row,col)); 
   }
   public int numberOfOpenSites()       // number of open sites
   {   
      return openSiteNum;
   }
   public boolean percolates()              // does the system percolate?
   { if (nDim == 1)
	   if (isOpen(1,1)) return true;
	   else return false;
	 else return cgrid.connected(0,nDim*nDim+1); }
   public static void main(String[] args)   // test client (optional)
   {
      int NN = Integer.parseInt(args[0]);
      Percolation p = new Percolation(NN);
      while(!p.percolates())//while not percolated randomly choose one place to open
      {   
         int row_t = StdRandom.uniform(NN)+1;
         int col_t = StdRandom.uniform(NN)+1;
         p.open(row_t,col_t);
      }
      double prob = ((double)p.numberOfOpenSites())/(NN*NN);
      StdOut.print(prob);
   }
}